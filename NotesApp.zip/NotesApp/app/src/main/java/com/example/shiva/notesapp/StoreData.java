package com.example.shiva.notesapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class StoreData extends SQLiteOpenHelper {
    private String tableName="note";
    private static String dbName="NOTES";
    private static int version=1;
    public StoreData(Context context) {
        super(context, dbName, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql="CREATE TABLE IF NOT EXISTS "+tableName+"(heading VARCHAR,data VARCHAR)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void  addNote(String head,String noteD){
        SQLiteDatabase addData=getWritableDatabase();
        ContentValues addVal=new ContentValues();
        addVal.put("heading",head);
        addVal.put("data",noteD);
        addData.insert(tableName,null,addVal);
        Log.i("Inserted","Done");
    }
    public void updateNote(String head,String noteD){
        SQLiteDatabase addData=getWritableDatabase();
        ContentValues addVal=new ContentValues();
        addVal.put("data",noteD);
        addData.update(tableName,addVal,"heading =?",new String[]{head});
    }
    public void removeNote(String head){
        SQLiteDatabase reNo=getWritableDatabase();
        reNo.delete(tableName,"heading =?",new String[]{head});
    }
    public  Cursor getHeading(){
        SQLiteDatabase addData=getReadableDatabase();
        return addData.rawQuery("SELECT heading FROM "+tableName,null);

    }

    public Cursor getNoteData(String data){
        SQLiteDatabase addNo=getReadableDatabase();
        return addNo.rawQuery("SELECT data  FROM NOTE WHERE heading =?", new String[]{data});
    }


}

package com.example.shiva.notesapp;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;

public class DisplayData {
    Cursor showData;
    StoreData passwal;
    public DisplayData(Context myCon){
        passwal=new StoreData(myCon);
    }
    public  void populateList(){

        try {
            showData = passwal.getHeading();
            int head = showData.getColumnIndex("heading");
            if(showData.getCount()>0){
                showData.moveToFirst();
                while (showData != null) {
                    MainActivity.listData.add(showData.getString(head));
                    showData.moveToNext();
                    MainActivity.myAdap.notifyDataSetChanged();
                }
            }

            Log.i("Table ","ListPopulated");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public  String  populateNoteData(String data){
       int da = 0;
        try {
            showData =passwal.getNoteData(data);
           da= showData.getColumnIndex("data");
            showData.moveToNext();
            Log.i("Table ","Note populated");
        }catch (Exception e){
            e.printStackTrace();
        }
            return showData.getString(da);

    }


}

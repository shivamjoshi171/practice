package com.example.shiva.notesapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.EditText;

public class notes extends AppCompatActivity {
    int position;
    EditText noteDa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        Intent i=getIntent();
        noteDa=(EditText)findViewById(R.id.editText);
        position=i.getIntExtra("noteID",-1);
        Log.i("P",Integer.toString(position));
        if(position>=0) {
            String p = MainActivity.ob.populateNoteData(MainActivity.listData.get(position));
            noteDa.setText(p);
            Log.i("Table ", "Data Displayed");
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(position==-1){
            new StoreData(getApplicationContext()).addNote(MainActivity.listData.get(MainActivity.listData.size()-1),noteDa.getText().toString());
            Log.i("Table ","Yes BackPressed");
            MainActivity.myAdap.notifyDataSetChanged();
        }else{
            new StoreData(getApplicationContext()).updateNote(MainActivity.listData.get(position),noteDa.getText().toString());
        }
    }
}
